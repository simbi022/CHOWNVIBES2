-- ============================================================
-- CHOW 'N' VIBES — CLEAN DATABASE MIGRATION
-- ============================================================

create extension if not exists "pgcrypto";


-- ============================================================
-- 1. PROFILES
-- ============================================================

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  role text not null default 'waiter'
    check (role in ('waiter', 'supervisor', 'accountant')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);


-- ============================================================
-- 2. MENU ITEMS
-- ============================================================

create table public.menu_items (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text not null,
  price numeric(12,2) not null default 0
    check (price >= 0),
  image_url text,
  description text,
  available boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);


-- ============================================================
-- 3. ORDERS
-- ============================================================

create table public.orders (
  id uuid primary key default gen_random_uuid(),

  customer_name text,
  customer_phone text,

  waiter_id uuid references public.profiles(id)
    on delete set null,

  order_type text not null default 'staff'
    check (order_type in ('staff', 'vip')),

  status text not null default 'pending'
    check (
      status in (
        'pending',
        'confirmed',
        'preparing',
        'ready',
        'completed',
        'cancelled'
      )
    ),

  payment_method text
    check (
      payment_method is null
      or payment_method in ('cash', 'card', 'transfer')
    ),

  payment_status text not null default 'unpaid'
    check (
      payment_status in ('unpaid', 'paid', 'refunded')
    ),

  subtotal numeric(12,2) not null default 0,
  total numeric(12,2) not null default 0,

  notes text,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);


-- ============================================================
-- 4. ORDER ITEMS
-- ============================================================

create table public.order_items (
  id uuid primary key default gen_random_uuid(),

  order_id uuid not null
    references public.orders(id)
    on delete cascade,

  menu_item_id uuid references public.menu_items(id)
    on delete set null,

  item_name text not null,

  quantity integer not null default 1
    check (quantity > 0),

  unit_price numeric(12,2) not null default 0
    check (unit_price >= 0),

  total_price numeric(12,2)
    generated always as (quantity * unit_price) stored,

  created_at timestamptz not null default now()
);


-- ============================================================
-- 5. UPDATED_AT FUNCTION
-- ============================================================

create or replace function public.set_updated_at()
returns trigger
language plpgsql
security invoker
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;


-- ============================================================
-- 6. UPDATED_AT TRIGGERS
-- ============================================================

create trigger profiles_updated_at
before update on public.profiles
for each row
execute function public.set_updated_at();

create trigger menu_items_updated_at
before update on public.menu_items
for each row
execute function public.set_updated_at();

create trigger orders_updated_at
before update on public.orders
for each row
execute function public.set_updated_at();


-- ============================================================
-- 7. ROLE HELPER
-- ============================================================

create or replace function public.current_user_role()
returns text
language sql
stable
security definer
set search_path = public
as $$
  select role
  from public.profiles
  where id = auth.uid()
  limit 1;
$$;


-- ============================================================
-- 8. MANAGEMENT HELPER
-- ============================================================

create or replace function public.is_management()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.profiles
    where id = auth.uid()
      and role in ('supervisor', 'accountant')
  );
$$;


-- ============================================================
-- 9. STAFF LIMIT — MAXIMUM 4
-- ============================================================

create or replace function public.enforce_staff_limit()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin

  if (select count(*) from public.profiles) >= 4 then
    raise exception
      'Staff limit reached. Maximum of 4 staff accounts is allowed.';
  end if;

  return new;

end;
$$;

create trigger staff_limit_trigger
before insert on public.profiles
for each row
execute function public.enforce_staff_limit();


-- ============================================================
-- 10. ENABLE ROW LEVEL SECURITY
-- ============================================================

alter table public.profiles enable row level security;
alter table public.menu_items enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;


-- ============================================================
-- 11. PROFILES POLICIES
-- ============================================================

create policy "Users can view own profile"
on public.profiles
for select
to authenticated
using (
  id = auth.uid()
);

create policy "Management can view all profiles"
on public.profiles
for select
to authenticated
using (
  public.is_management()
);

create policy "Users can update own profile"
on public.profiles
for update
to authenticated
using (
  id = auth.uid()
)
with check (
  id = auth.uid()
);

create policy "Management can update profiles"
on public.profiles
for update
to authenticated
using (
  public.is_management()
)
with check (
  public.is_management()
);


-- ============================================================
-- 12. MENU POLICIES
-- ============================================================

create policy "Anyone can view available menu"
on public.menu_items
for select
to anon, authenticated
using (
  available = true
);

create policy "Management can manage menu"
on public.menu_items
for all
to authenticated
using (
  public.is_management()
)
with check (
  public.is_management()
);


-- ============================================================
-- 13. ORDERS — VIEW
-- ============================================================

create policy "Staff can view their orders"
on public.orders
for select
to authenticated
using (
  waiter_id = auth.uid()
  or public.is_management()
);


-- ============================================================
-- 14. ORDERS — STAFF CREATE
-- ============================================================

create policy "Waiters can create their own orders"
on public.orders
for insert
to authenticated
with check (
  waiter_id = auth.uid()
  and public.current_user_role() = 'waiter'
);


-- ============================================================
-- 15. ORDERS — MANAGEMENT CREATE
-- ============================================================

create policy "Management can create orders"
on public.orders
for insert
to authenticated
with check (
  public.is_management()
);


-- ============================================================
-- 16. VIP CUSTOMERS CAN CREATE ORDERS
-- ============================================================

create policy "VIP customers can create orders"
on public.orders
for insert
to anon
with check (
  order_type = 'vip'
  and waiter_id is null
);


-- ============================================================
-- 17. ORDERS — UPDATE
-- ============================================================

create policy "Staff can update their orders"
on public.orders
for update
to authenticated
using (
  waiter_id = auth.uid()
  or public.is_management()
)
with check (
  waiter_id = auth.uid()
  or public.is_management()
);


-- ============================================================
-- 18. ORDERS — DELETE
-- ============================================================

create policy "Management can delete orders"
on public.orders
for delete
to authenticated
using (
  public.is_management()
);


-- ============================================================
-- 19. ORDER ITEMS — VIEW
-- ============================================================

create policy "Staff can view order items"
on public.order_items
for select
to authenticated
using (
  exists (
    select 1
    from public.orders o
    where o.id = order_items.order_id
      and (
        o.waiter_id = auth.uid()
        or public.is_management()
      )
  )
);


-- ============================================================
-- 20. ORDER ITEMS — STAFF INSERT
-- ============================================================

create policy "Staff can create order items"
on public.order_items
for insert
to authenticated
with check (
  exists (
    select 1
    from public.orders o
    where o.id = order_items.order_id
      and (
        o.waiter_id = auth.uid()
        or public.is_management()
      )
  )
);


-- ============================================================
-- 21. ORDER ITEMS — VIP INSERT
-- ============================================================

create policy "VIP customers can create order items"
on public.order_items
for insert
to anon
with check (
  exists (
    select 1
    from public.orders o
    where o.id = order_items.order_id
      and o.order_type = 'vip'
  )
);


-- ============================================================
-- 22. ORDER ITEMS — UPDATE
-- ============================================================

create policy "Staff can update order items"
on public.order_items
for update
to authenticated
using (
  exists (
    select 1
    from public.orders o
    where o.id = order_items.order_id
      and (
        o.waiter_id = auth.uid()
        or public.is_management()
      )
  )
)
with check (
  exists (
    select 1
    from public.orders o
    where o.id = order_items.order_id
      and (
        o.waiter_id = auth.uid()
        or public.is_management()
      )
  )
);


-- ============================================================
-- 23. ORDER ITEMS — DELETE
-- ============================================================

create policy "Management can delete order items"
on public.order_items
for delete
to authenticated
using (
  public.is_management()
);


-- ============================================================
-- 24. INDEXES
-- ============================================================

create index profiles_role_idx
on public.profiles(role);

create index orders_waiter_id_idx
on public.orders(waiter_id);

create index orders_created_at_idx
on public.orders(created_at desc);

create index orders_status_idx
on public.orders(status);

create index orders_order_type_idx
on public.orders(order_type);

create index order_items_order_id_idx
on public.order_items(order_id);


-- ============================================================
-- 25. REALTIME
-- ============================================================

alter table public.orders replica identity full;

alter table public.order_items replica identity full;

alter publication supabase_realtime
add table public.orders;

alter publication supabase_realtime
add table public.order_items;


-- ============================================================
-- COMPLETE
-- ============================================================